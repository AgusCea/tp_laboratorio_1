#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "Employee.h"
#include "parser.h"

int controller_loadFromText(char* path, LinkedList* pArrayListEmployee)
{
    FILE* pFile;

    pFile = fopen(path, "r");
    if(pFile == NULL || pArrayListEmployee == NULL)
    {
        printf("\nError, puntero a NULL. ");
        return 0;
    }

    ll_clear(pArrayListEmployee);
    parser_EmployeeFromText(pFile, pArrayListEmployee);

    fclose(pFile);

    return 1;
}


int controller_loadFromBinary(char* path, LinkedList* pArrayListEmployee)
{
    FILE* pFile;

    pFile = fopen(path, "rb");
    if(pFile == NULL || pArrayListEmployee == NULL)
    {
        printf("\nError, puntero a NULL. ");
        return 0;
    }

    ll_clear(pArrayListEmployee);
    parser_EmployeeFromBinary(pFile, pArrayListEmployee);

    fclose(pFile);

    return 1;
}


int controller_addEmployee(LinkedList* pArrayListEmployee)
{
    Employee* pEmployee = NULL;
    int id;
    char nombre[21];
    int sueldo;
    int horasTrabajadas;
    int flag = 0;

    if(pArrayListEmployee == NULL)
    {
        printf("\nError, puntero a NULL. ");
        return flag;
    }

    pEmployee = employee_new();
    if(pEmployee != NULL)
    {
        do{
            printf("\nIngresar id: ");
            scanf("%d", &id);
        }while(!employee_setId(pEmployee, id));

        do{
            printf("\nIngresar nombre: ");
            fflush(stdin);
            gets(nombre);
        }while(!employee_setNombre(pEmployee, nombre));

        do{
            printf("\nIngresar horas trabajadas (0-325): ");
            scanf("%d", &horasTrabajadas);
        }while(!employee_setHorasTrabajadas(pEmployee, horasTrabajadas));

        do{
            printf("\nIngresar sueldo (50000 max): ");
            scanf("%d", &sueldo);
        }while(!employee_setSueldo(pEmployee, sueldo));

        ll_add(pArrayListEmployee, pEmployee);
        printf("\nEmpleado cargado con exito!! ");
        flag = 1;
    }

    return flag;
}


int controller_editEmployee(LinkedList* pArrayListEmployee)
{
    Employee* pEmployee = NULL;
    int isEmpty, size, i, index, auxId, opcion;

    int id;
    char nombre[21];
    int horasTrabajadas;
    int sueldo;

    isEmpty = ll_isEmpty(pArrayListEmployee);

    if(pArrayListEmployee == NULL)
    {
        printf("\nError, puntero a NULL. ");
        return 0;
    }
    else if(isEmpty == 1)
    {
        printf("\nLa lista esta vacia. ");
        return 0;
    }

    pEmployee = employee_new();
    if(pEmployee == NULL)
    {
        printf("\nError, no se pudo reservar memoria. ");
        return 0;
    }

    printf("\nIngresar id: ");
    scanf("%d", &auxId);

    size = ll_len(pArrayListEmployee);
    index = -1;

    for(i=0; i<size; i++)
    {
        pEmployee = ll_get(pArrayListEmployee, i);
        employee_getId(pEmployee, &id);
        if(auxId == id)
        {
            index = i;
            break;
        }
    }
    if(index == -1)
    {
        printf("\nError, el id ingresado no existe. ");
        return 0;
    }

    employee_getId(pEmployee, &id);
    employee_getNombre(pEmployee, nombre);
    employee_getHorasTrabajadas(pEmployee, &horasTrabajadas);
    employee_getSueldo(pEmployee, &sueldo);

    printf("%d,%s,%d,%d\n", id, nombre, horasTrabajadas, sueldo);

    printf("\n*** Menu de opciones ***");
    printf("\n1- Modificar nombre. ");
    printf("\n2- Modificar horas trabajadas. ");
    printf("\n3- Modificar sueldo. ");
    printf("\n4- SALIR. ");
    printf("\nIngresar opcion: ");
    scanf("%d", &opcion);

    switch(opcion)
    {
    case 1:
        do{
            printf("\nIngresar nombre: ");
            fflush(stdin);
            gets(nombre);
        }while(!employee_setNombre(pEmployee, nombre));
        break;

    case 2:
        do{
            printf("\nIngresar horas trabajadas (0-325): ");
            scanf("%d", &horasTrabajadas);
        }while(!employee_setHorasTrabajadas(pEmployee, horasTrabajadas));
        break;

    case 3:
        do{
            printf("\nIngresar sueldo (50000 max): ");
            scanf("%d", &sueldo);
        }while(!employee_setSueldo(pEmployee, sueldo));
        break;

    case 4:
        printf("\nNo se realizo ninguna modificacion. ");
        return 0;

    default:
        printf("\nOpcion invalida. ");
        return 0;
    }

    ll_set(pArrayListEmployee, index, pEmployee);
    printf("\nListo!! ");

    return 1;
}


int controller_removeEmployee(LinkedList* pArrayListEmployee)
{
    Employee* pEmployee = NULL;
    int isEmpty, size, i, index, auxId;

    int id;
    char nombre[21];
    int horasTrabajadas;
    int sueldo;

    isEmpty = ll_isEmpty(pArrayListEmployee);

    if(pArrayListEmployee == NULL)
    {
        printf("\nError, puntero a NULL. ");
        return 0;
    }
    else if(isEmpty == 1)
    {
        printf("\nLa lista esta vacia. ");
        return 0;
    }

    pEmployee = employee_new();
    if(pEmployee == NULL)
    {
        printf("\nError, no se pudo reservar memoria. ");
        return 0;
    }

    printf("\nIngresar id: ");
    scanf("%d", &auxId);

    size = ll_len(pArrayListEmployee);
    index = -1;

    for(i=0; i<size; i++)
    {
        pEmployee = ll_get(pArrayListEmployee, i);
        employee_getId(pEmployee, &id);
        if(auxId == id)
        {
            index = i;
            break;
        }
    }
    if(index == -1)
    {
        printf("\nError, el id ingresado no existe. ");
        return 0;
    }

    employee_getId(pEmployee, &id);
    employee_getNombre(pEmployee, nombre);
    employee_getHorasTrabajadas(pEmployee, &horasTrabajadas);
    employee_getSueldo(pEmployee, &sueldo);

    printf("%d,%s,%d,%d\n", id, nombre, horasTrabajadas, sueldo);

    ll_remove(pArrayListEmployee, index);
    printf("\nBorrado!! ");

    return 1;
}


int controller_ListEmployee(LinkedList* pArrayListEmployee)
{
    Employee* pEmployee = NULL;
    int isEmpty, size, i;

    int id;
    char nombre[21];
    int horasTrabajadas;
    int sueldo;

    isEmpty = ll_isEmpty(pArrayListEmployee);

    if(pArrayListEmployee == NULL)
    {
        printf("\nError, puntero a NULL. ");
        return 0;
    }
    else if(isEmpty == 1)
    {
        printf("\nLa lista esta vacia. ");
        return 0;
    }

    pEmployee = employee_new();
    if(pEmployee == NULL)
    {
        printf("\nError, no se pudo reservar memoria. ");
        return 0;
    }

    size = ll_len(pArrayListEmployee);
    for(i=0; i<size; i++)
    {
        pEmployee = ll_get(pArrayListEmployee, i);
        employee_getId(pEmployee, &id);
        employee_getNombre(pEmployee, nombre);
        employee_getHorasTrabajadas(pEmployee, &horasTrabajadas);
        employee_getSueldo(pEmployee, &sueldo);

        printf("%d, %s, %d, %d\n", id, nombre, horasTrabajadas, sueldo);
    }

    return 1;
}


int controller_sortEmployee(LinkedList* pArrayListEmployee)
{
    int isEmpty, opcion;

    isEmpty = ll_isEmpty(pArrayListEmployee);

    if(pArrayListEmployee == NULL)
    {
        printf("\nError, puntero a NULL. ");
        return 0;
    }
    else if(isEmpty == 1)
    {
        printf("\nLa lista esta vacia. ");
        return 0;
    }

    printf("\n*** Menu de opciones ***");
    printf("\n1- Ordenar Empleados x id. ");
    printf("\n2- Ordenar Empleados x nombre. ");
    printf("\n3- Ordenar Empleados x horas trabajadas. ");
    printf("\n4- Ordenar Empleados x sueldo. ");
    printf("\n5- SALIR. ");
    printf("\nIngresar opcion: ");
    scanf("%d", &opcion);

    switch(opcion)
    {
    case 1:
        printf("\nEspere un momento. ");
        ll_sort(pArrayListEmployee, employee_CompareById, 1);
        printf("\nListo!! ");
        break;

    case 2:
        printf("\nEspere un momento. ");
        ll_sort(pArrayListEmployee, employee_CompareByName, 1);
        printf("\nListo!! ");
        break;

    case 3:
        printf("\nEspere un momento. ");
        ll_sort(pArrayListEmployee, employee_CompareByWorkTime, 1);
        printf("\nListo!! ");
        break;

    case 4:
        printf("\nEspere un momento. ");
        ll_sort(pArrayListEmployee, employee_CompareBySalary, 1);
        printf("\nListo!! ");
        break;

    case 5:
        printf("\nNo se realizo ningun ordenamiento. ");
        return 0;

    default:
        printf("\nOpcion invalida. ");
        return 0;
    }

    return 1;
}


int controller_saveAsText(char* path, LinkedList* pArrayListEmployee)
{
    FILE* pFile;
    int isEmpty, size, i;
    Employee* pEmployee = NULL;

    int id;
    char nombre[21];
    int horasTrabajadas;
    int sueldo;

    isEmpty = ll_isEmpty(pArrayListEmployee);

    if(pArrayListEmployee == NULL)
    {
        printf("\nError, puntero a NULL. ");
        return 0;
    }
    else if(isEmpty == 1)
    {
        printf("\nLa lista esta vacia. ");
        return 0;
    }

    pFile = fopen(path, "w");
    if(pFile == NULL)
    {
        printf("Error, no se puede abrir el archivo. \n");
        return 0;
    }
    size = ll_len(pArrayListEmployee);

    fprintf(pFile, "id,nombre,horasTrabajadas,sueldo\n");
    for(i=0; i<size; i++)
    {
        pEmployee = ll_get(pArrayListEmployee, i);
        employee_getId(pEmployee, &id);
        employee_getNombre(pEmployee, nombre);
        employee_getHorasTrabajadas(pEmployee, &horasTrabajadas);
        employee_getSueldo(pEmployee, &sueldo);

        fprintf(pFile, "%d,%s,%d,%d\n", id, nombre, horasTrabajadas, sueldo);
    }
    printf("\nListo!! ");
    fclose(pFile);

    return 1;
}


int controller_saveAsBinary(char* path, LinkedList* pArrayListEmployee)
{
    FILE* pFile;
    int isEmpty, size, i;
    Employee* pEmployee = NULL;

    isEmpty = ll_isEmpty(pArrayListEmployee);

    if(pArrayListEmployee == NULL)
    {
        printf("\nError, puntero a NULL. ");
        return 0;
    }
    else if(isEmpty == 1)
    {
        printf("\nLa lista esta vacia. ");
        return 0;
    }

    pEmployee = employee_new();
    if(pEmployee == NULL)
    {
        printf("\nError, no se pudo reservar memoria. ");
        return 0;
    }

    pFile = fopen(path, "wb");
    if(pFile == NULL)
    {
        printf("Error, no se puede abrir el archivo. \n");
        return 0;
    }
    size = ll_len(pArrayListEmployee);

    for(i=0; i<size; i++)
    {
        pEmployee = ll_get(pArrayListEmployee, i);
        fwrite(pEmployee, sizeof(Employee), 1, pFile);
    }
    printf("\nListo!! ");
    fclose(pFile);

    return 1;
}

