#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Controller.h"
#include "Employee.h"

/****************************************************
    Menu:
     1. Cargar los datos de los empleados desde el archivo data.csv (modo texto).
     2. Cargar los datos de los empleados desde el archivo data.csv (modo binario).
     3. Alta de empleado
     4. Modificar datos de empleado
     5. Baja de empleado
     6. Listar empleados
     7. Ordenar empleados
     8. Guardar los datos de los empleados en el archivo data.csv (modo texto).
     9. Guardar los datos de los empleados en el archivo data.csv (modo binario).
    10. Salir
*****************************************************/

int menu();

int main()
{
    char path[] = "data.csv";
    LinkedList* pArrayListEmployee = NULL;
    int salir = 0;


    pArrayListEmployee = ll_newLinkedList();

    do{
        switch(menu())
        {
        case 1:
            //controller_loadFromText(path, pArrayListEmployee);
            controller_loadFromText("codigoBorrador.csv", pArrayListEmployee);
            break;

        case 2:
            controller_loadFromBinary(path, pArrayListEmployee);
            //controller_loadFromBinary("codigoBorrador.csv", pArrayListEmployee);
            break;

        case 3:
            controller_addEmployee(pArrayListEmployee);
            break;

        case 4:
            controller_editEmployee(pArrayListEmployee);
            break;

        case 5:
            controller_removeEmployee(pArrayListEmployee);
            break;

        case 6:
            controller_ListEmployee(pArrayListEmployee);
            break;

        case 7:
            controller_sortEmployee(pArrayListEmployee);
            break;

        case 8:
            controller_saveAsText(path, pArrayListEmployee);
            //controller_saveAsText("codigoBorrador.csv", pArrayListEmployee);
            break;

        case 9:
            controller_saveAsBinary(path, pArrayListEmployee);
            //controller_saveAsBinary("codigoBorrador.csv", pArrayListEmployee);
            break;

        case 10:
            printf("\nSalida! ");
            salir = 1;
            break;

        default:
            printf("\nOpcion invalida ");
            break;
        }
        system("pause");
    }while(!salir);

    return 0;
}

int menu()
{
    int option;

    system("cls");
    printf("Menu: ");
    printf("\n1. Cargar los datos de los empleados desde el archivo data.csv (modo texto).");
    printf("\n2. Cargar los datos de los empleados desde el archivo data.csv (modo binario).");
    printf("\n3. Alta de empleado");
    printf("\n4. Modificar datos de empleado");
    printf("\n5. Baja de empleado");
    printf("\n6. Listar empleados");
    printf("\n7. Ordenar empleados");
    printf("\n8. Guardar los datos de los empleados en el archivo data.csv (modo texto).");
    printf("\n9. Guardar los datos de los empleados en el archivo data.csv (modo binario).");
    printf("\n10. SALIR");
    printf("\nIngresar opcion: ");
    scanf("%d", &option);

    return option;
}
