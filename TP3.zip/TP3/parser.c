#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Employee.h"

int parser_EmployeeFromText(FILE* pFile, LinkedList* pArrayListEmployee)
{
    Employee* pEmployee = NULL;
    char id[10], nombre[20], horasTrabajadas[10], sueldo[10];

    pEmployee = employee_newParametros(id, nombre, horasTrabajadas, sueldo);
    if(pEmployee == NULL)
    {
        printf("\nError, no se pudo reservar memoria. ");
        return 0;
    }

    fscanf(pFile, "%[^,],%[^,],%[^,],%[^\n]\n", id, nombre, horasTrabajadas, sueldo);
    while(!feof(pFile))
    {
        fscanf(pFile, "%[^,],%[^,],%[^,],%[^\n]\n", id, nombre, horasTrabajadas, sueldo);
        pEmployee = employee_newParametros(id, nombre, horasTrabajadas, sueldo);
        ll_add(pArrayListEmployee, pEmployee);
    }
    printf("\nLista cargada! ");

    return 1;
}

int parser_EmployeeFromBinary(FILE* pFile, LinkedList* pArrayListEmployee)
{
    Employee* pEmployee = NULL;
    int cant;

    pEmployee = employee_new();
    if(pEmployee == NULL)
    {
        printf("\nError, no se pudo reservar memoria. ");
        return 0;
    }

    while(!feof(pFile))
    {
        pEmployee = employee_new();
        cant = fread(pEmployee, sizeof(Employee), 1, pFile);
        if(cant == 1)
        {
            ll_add(pArrayListEmployee, pEmployee);
        }
    }
    printf("\nLista cargada! ");

    return 1;
}
