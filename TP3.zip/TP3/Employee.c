#include <stdlib.h>
#include "Employee.h"
#include <string.h>

Employee* employee_new()
{
    Employee* pEmployee = NULL;
    pEmployee = (Employee*) malloc(sizeof(Employee));
    return pEmployee;
}
Employee* employee_newParametros(char* idStr,char* nombreStr,char* horasTrabajadasStr,char* sueldoStr)
{
    Employee* pEmployee = NULL;
    pEmployee = (Employee*) malloc(sizeof(Employee));

    employee_setId(pEmployee, atoi(idStr));
    employee_setNombre(pEmployee, nombreStr);
    employee_setHorasTrabajadas(pEmployee, atoi(horasTrabajadasStr));
    employee_setSueldo(pEmployee, atoi(sueldoStr));

    return pEmployee;
}

int employee_setNombre(Employee* this,char* nombre)
{
    int flag = 0;

    if(this != NULL && nombre != NULL)
    {
        strcpy(this->nombre, nombre);
        flag = 1;
    }
    return flag;
}

int employee_getNombre(Employee* this,char* nombre)
{
    int flag = 0;

    if(this != NULL && nombre != NULL)
    {
        strcpy(nombre, this->nombre);
        flag = 1;
    }
    return flag;
}

int employee_setSueldo(Employee* this,int sueldo)
{
    int flag = 0;

    if(this != NULL && sueldo > 0 && sueldo <= 50000)
    {
        this->sueldo = sueldo;
        flag = 1;
    }
    return flag;
}
int employee_getSueldo(Employee* this,int* sueldo)
{
    int flag = 0;

    if(this != NULL && sueldo != NULL)
    {
        *sueldo = this->sueldo;
        flag = 1;
    }
    return flag;
}

int employee_setId(Employee* this,int id)
{
    int flag = 0;

    if(this != NULL && id > 0)
    {
        this->id = id;
        flag = 1;
    }
    return flag;
}

int employee_getId(Employee* this,int* id)
{
    int flag = 0;

    if(this != NULL && id != NULL)
    {
        *id = this->id;
        flag = 1;
    }
    return flag;
}

int employee_setHorasTrabajadas(Employee* this,int horasTrabajadas)
{
    int flag = 0;

    if(this != NULL && horasTrabajadas >= 0 && horasTrabajadas <= 325)
    {
        this->horasTrabajadas = horasTrabajadas;
        flag = 1;
    }
    return flag;
}

int employee_getHorasTrabajadas(Employee* this,int* horasTrabajdas)
{
    int flag = 0;

    if(this != NULL && horasTrabajdas != NULL)
    {
        *horasTrabajdas = this->horasTrabajadas;
        flag = 1;
    }
    return flag;
}


int employee_CompareByName(void* e1, void* e2)
{
    if(e1 == NULL || e2 == NULL)
    {
        return 0;
    }

    Employee* emp1 = (Employee*)e1;
    Employee* emp2 = (Employee*)e2;

    return strcmp(emp1->nombre, emp2->nombre);
}

int employee_CompareById(void* e1, void* e2)
{
    if(e1 == NULL || e2 == NULL)
    {
        return 0;
    }

    Employee* emp1 = (Employee*)e1;
    Employee* emp2 = (Employee*)e2;

    if(emp1->id > emp2->id)
    {
        return 1;
    }
    else
    {
        if(emp1->id < emp2->id)
        {
            return -1;
        }
        else
        {
            return 0;
        }
    }

    return strcmp(emp1->nombre, emp2->nombre);
}

int employee_CompareByWorkTime(void* e1, void* e2)
{
    if(e1 == NULL || e2 == NULL)
    {
        return 0;
    }

    Employee* emp1 = (Employee*)e1;
    Employee* emp2 = (Employee*)e2;

    if(emp1->horasTrabajadas > emp2->horasTrabajadas)
    {
        return 1;
    }
    else
    {
        if(emp1->horasTrabajadas < emp2->horasTrabajadas)
        {
            return -1;
        }
        else
        {
            return 0;
        }
    }

    return strcmp(emp1->nombre, emp2->nombre);
}

int employee_CompareBySalary(void* e1, void* e2)
{
    if(e1 == NULL || e2 == NULL)
    {
        return 0;
    }

    Employee* emp1 = (Employee*)e1;
    Employee* emp2 = (Employee*)e2;

    if(emp1->sueldo > emp2->sueldo)
    {
        return 1;
    }
    else
    {
        if(emp1->sueldo < emp2->sueldo)
        {
            return -1;
        }
        else
        {
            return 0;
        }
    }

    return strcmp(emp1->nombre, emp2->nombre);
}

